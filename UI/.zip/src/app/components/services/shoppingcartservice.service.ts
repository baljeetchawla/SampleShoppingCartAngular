import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductModel } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ShoppingcartserviceService {

  constructor(private http: HttpClient) { }
readonly baseUrl ='http://localhost:61964/api/ShoppingCart';
listProducts: any[];
listCart: any[];
productDetails: ProductModel;
  getProductsList(): any{
    this.http.get<any>(this.baseUrl+'/GetProducts').subscribe(data => {
      this.listProducts = data.value;
    })        
  }

  getCartInfo(): any{
    this.http.get<any>(this.baseUrl+'/Checkout').subscribe(data => {
      this.listCart = data.value;
    })        
  }

  getProductById(productId: number): any{
    this.http.get<any>(this.baseUrl+'/GetProductByID?id='+ productId).subscribe(data => {
      this.productDetails = data.value;
    })        
  }
}
