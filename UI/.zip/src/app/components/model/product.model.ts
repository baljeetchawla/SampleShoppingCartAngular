export class ProductModel {
    ProductId : number;
    ProductTitle: string;
    Description: string;
    Price: string;
    ModelNumber: string;
    ImageName: string;
}
