import { Component, OnInit } from '@angular/core';
import { ShoppingcartserviceService } from '../../services/shoppingcartservice.service';
import {Router} from "@angular/router";

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  productsArray: any;
  constructor(public service: ShoppingcartserviceService,
    private router: Router) {

     }

  ngOnInit(): void {
     this.service.getProductsList();
    
  }
  productDetails(productId){
      const fullPath = 'shoppingcart/productslist/details';
      this.router.navigate(['/details']);

     // this.router.navigate([fullPath]);
  }
}
