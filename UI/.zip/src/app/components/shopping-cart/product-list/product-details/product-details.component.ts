import { Component, OnInit } from '@angular/core';
import { ShoppingcartserviceService } from '../../../services/shoppingcartservice.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(public service: ShoppingcartserviceService) { }

  ngOnInit(): void {
    this.service.getProductsList();
  }

}
